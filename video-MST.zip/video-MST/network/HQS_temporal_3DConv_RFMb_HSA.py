import torch
import torch.nn as nn
import torch.nn.functional as F
from sci_utilities import A_operator, At_operator

from pdb import set_trace as stx
import numbers


from torchvision import transforms

from einops import rearrange

#import torch.nn as nn
#import torch
#import torch.nn.functional as F
#from einops import rearrange
import math
import warnings
from torch.nn.init import _calculate_fan_in_and_fan_out

class InputCvBlock(nn.Module):
    '''(Conv with num_in_frames groups => BN => ReLU) + (Conv => BN => ReLU)'''

    def __init__(self, num_in_frames, out_ch):
        super(InputCvBlock, self).__init__()
        self.interm_ch = 30
        self.convblock = nn.Sequential(
            nn.Conv3d(num_in_frames, num_in_frames * self.interm_ch, \
                      kernel_size=3, padding=1, groups=num_in_frames, bias=True),
            # nn.BatchNorm2d(num_in_frames * self.interm_ch),
            nn.ReLU(inplace=True),
            nn.Conv3d(num_in_frames * self.interm_ch, out_ch, kernel_size=3, padding=1, bias=True),
            # nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.convblock(x)


class CvBlock(nn.Module):
    '''(Conv2d => BN => ReLU) x 2'''

    def __init__(self, in_ch, out_ch):
        super(CvBlock, self).__init__()
        self.convblock = nn.Sequential(
            nn.Conv3d(in_ch, out_ch, kernel_size=3, padding=1, bias=True),
            # nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_ch, out_ch, kernel_size=3, padding=1, bias=True),
            # nn.BatchNorm2d(out_ch),
            # nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.convblock(x) + x


class DownBlock(nn.Module):
    '''Downscale + (Conv2d => BN => ReLU)*2'''

    def __init__(self, in_ch, out_ch):
        super(DownBlock, self).__init__()
        self.convblock = nn.Sequential(
            nn.Conv3d(in_ch, out_ch, kernel_size=3, padding=1, stride=(1, 2, 2), bias=True),
            # nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            CvBlock(out_ch, out_ch)
        )

    def forward(self, x):
        return self.convblock(x)


class UpBlock(nn.Module):
    '''(Conv2d => BN => ReLU)*2 + Upscale'''

    def __init__(self, in_ch, out_ch):
        super(UpBlock, self).__init__()
        self.convblock = nn.Sequential(
            CvBlock(in_ch, in_ch),
            nn.Conv3d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        )

    def forward(self, x):
        return F.interpolate(self.convblock(x), scale_factor=(1, 2, 2))


class OutputCvBlock(nn.Module):
    '''Conv2d => BN => ReLU => Conv2d'''

    def __init__(self, in_ch, out_ch):
        super(OutputCvBlock, self).__init__()
        self.convblock = nn.Sequential(
            nn.Conv3d(in_ch, in_ch, kernel_size=3, padding=1, bias=True),
            # nn.BatchNorm2d(in_ch),
            nn.ReLU(inplace=True),
            nn.Conv3d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        )

    def forward(self, x):
        return self.convblock(x)


class BasicBlock(torch.nn.Module):
    def __init__(self, args, layer):
        super(BasicBlock, self).__init__()

        self.eta_step = nn.Parameter(torch.Tensor([0.01]))
        # define head module

        self.n_channels = args.n_channels

        self.chs_lyr0 = 32
        self.chs_lyr1 = 64
        self.chs_lyr2 = 128
        self.k = 3

        self.inc = InputCvBlock(num_in_frames=args.n_channels + 1, out_ch=self.chs_lyr0)
        self.downc0 = DownBlock(in_ch=self.chs_lyr0, out_ch=self.chs_lyr1)
        self.downc1 = DownBlock(in_ch=self.chs_lyr1, out_ch=self.chs_lyr2)
        if layer == 0:
            self.upc2 = UpBlock(in_ch=self.chs_lyr2, out_ch=self.chs_lyr1)
            self.upc1 = UpBlock(in_ch=self.chs_lyr1, out_ch=self.chs_lyr0)
            self.outc = OutputCvBlock(in_ch=self.chs_lyr0, out_ch=1)
        else:
            self.upc2 = UpBlock(in_ch=self.chs_lyr2 * 2, out_ch=self.chs_lyr1)
            self.upc1 = UpBlock(in_ch=self.chs_lyr1 * 2, out_ch=self.chs_lyr0)
            self.outc = OutputCvBlock(in_ch=self.chs_lyr0 * 2, out_ch=1)

        self.relu = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

        self.unfold = nn.Unfold(kernel_size=3, stride=1, padding=1)
        self.generate_kernel1 = nn.Conv2d(in_channels=1, out_channels=self.chs_lyr2 * self.k * self.k, kernel_size=5, padding=1, stride=4, bias=None)
        self.generate_kernel2 = nn.Conv2d(in_channels=1, out_channels=self.chs_lyr1 * self.k * self.k, kernel_size=3, padding=1, stride=2, bias=None)
        self.generate_kernel3 = nn.Conv2d(in_channels=1, out_channels=self.chs_lyr0 * self.k * self.k, kernel_size=3, padding=1, stride=1, bias=None)



    @staticmethod
    def weight_init(m):
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, nonlinearity='relu')

    def reset_params(self):
        for _, m in enumerate(self.modules()):
            self.weight_init(m)

    def forward(self, v, y, y1, mask, Phisum, h_pre):

        # v -> 2 8 1 128 128
        # y -> 2 1 1 128 128
        # y1 -> 2 1 1 128 128
        # mask -> 8 1 128 128
        # Phisum -> 1 1 128 128

        yb = A_operator(v, mask)
        # yb -> 2 1 1 128 128
        y1 = y1 + (y - yb) # 求rk
        # y1 -> 2 1 1 128 128
        # x = v + At_operator((y1-yb)/Phisum, mask)
        x = v + At_operator((y1 - yb) / (Phisum + self.eta_step), mask)  # 求vk
        # x -> 2 8 1 128 128

        Phisum[Phisum == 0] = 1
        # Phisum -> 1 1 128 128
        y_ = y / Phisum  # 进行能量归一化
        # y_ -> 2 1 1 128 128
        y_ = y_.expand_as(v)
        # Y_ -> 2 8 1 128 128

        x_d0, x_d1, x_d2, x_d3, x_d4 = x.shape

        # # Spatial Denoising
        v = x.contiguous().view(x_d0, x_d2, x_d1, x_d3, x_d4)
        # v -> 2 1 8 128 128
        y_ = y_.contiguous().view(x_d0, x_d2, x_d1, x_d3, x_d4)
        # y_ -> 2 1 8 128 128

        h_curr = []

        x0 = self.inc(torch.cat((v, y_), dim=1))
        # x0 -> 2 32 8 128 128
        x1 = self.downc0(x0)
        # x1 -> 2 64 8 64 64
        x2 = self.downc1(x1)
        # x2 -> 2 128 8 32 32
        h_curr.append(x2)

        y_ = y_[:, :, 0, :, :]
        if len(h_pre) == 0:
            x2 = self.upc2(x2)
            h_curr.append(x2)
            x1 = self.upc1(x1 + x2)  # torch.Size([1, 32, 8, 128, 128])
            h_curr.append(x1)
            x = self.outc(x0 + x1)
        else:
            N, xC, xD, xH, xW = h_pre[0].size()
            kernel = self.relu(self.generate_kernel1(y_)).reshape([N, xC, self.k ** 2, xH, xW])
            similarity = []
            for i in range(xD):
                unfold_hpre = self.unfold(h_pre[0][:, :, i, :, :]).reshape([N, xC, -1, xH, xW])
                sim = self.sigmoid((kernel * unfold_hpre).sum(2))
                similarity.append(sim)
            similarity = torch.stack(similarity, dim=2) #torch.Size([1, 128, 8, 32, 32])
            h_pre[0] = similarity * h_pre[0]

            x2 = self.upc2(torch.cat((x2, h_pre[0]), dim=1))
            h_curr.append(x2)

            N, xC, xD, xH, xW = h_pre[1].size()
            kernel = self.relu(self.generate_kernel2(y_)).reshape([N, xC, self.k ** 2, xH, xW])
            similarity = []
            for i in range(xD):
                unfold_hpre = self.unfold(h_pre[1][:, :, i, :, :]).reshape([N, xC, -1, xH, xW])
                sim = self.sigmoid((kernel * unfold_hpre).sum(2))
                similarity.append(sim)
            similarity = torch.stack(similarity, dim=2)  # torch.Size([1, 128, 8, 32, 32])
            h_pre[1] = similarity * h_pre[1]
            x1 = self.upc1(torch.cat((x1 + x2, h_pre[1]), dim=1))
            h_curr.append(x1)

            N, xC, xD, xH, xW = h_pre[2].size()
            kernel = self.relu(self.generate_kernel3(y_)).reshape([N, xC, self.k ** 2, xH, xW])
            similarity = []
            for i in range(xD):
                unfold_hpre = self.unfold(h_pre[2][:, :, i, :, :]).reshape([N, xC, -1, xH, xW])
                sim = self.sigmoid((kernel * unfold_hpre).sum(2))
                similarity.append(sim)
            similarity = torch.stack(similarity, dim=2)  # torch.Size([1, 128, 8, 32, 32])
            h_pre[2] = similarity * h_pre[2]

            x = self.outc(torch.cat((x0 + x1, h_pre[2]), dim=1))  # torch.Size([1, 1, 8, 128, 128])

        x = v + x

        v = x.contiguous().view(x_d0, x_d1, x_d2, x_d3, x_d4)  # torch.Size([1, 8, 1, 128, 128])

        return v, y1, h_curr


class HQSNet(torch.nn.Module):
    def __init__(self, args):
        super(HQSNet, self).__init__()
        self.Phi_scale = nn.Parameter(torch.Tensor([0.01]))
        self.args = args
        onelayer = []
        self.LayerNo = args.layer_num

        for i in range(self.LayerNo):
            onelayer.append(BasicBlock(args, i))

        self.fcs = nn.ModuleList(onelayer)

    def forward(self, y, mask):
        # batch_size, nframes, ch, w, h = y.shape
        # y -> 2 1 1 128 128
        # mask -> 8 1 128 128
        Phisum = torch.sum(mask * mask, 0, keepdim=True)
        # Phisum -> 1 1 128 128
        # Phisum[Phisum == 0] = 1

        y1 = torch.zeros_like(y)
        hidden_state = []
        v = At_operator(y, mask)  # torch.Size([16, 1, 3, 64, 64])
        # v -> 2 8 1 128 128
        # h = [[None] * 4] * 8 * batch_size
        for i in range(self.LayerNo):
            v, y1, hidden_state = self.fcs[i](v, y, y1, mask, Phisum, hidden_state)

        y_pred = v
        # y_pred -> 2 8 1 128 128
        return y_pred

##########################################################################
## Layer Norm

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x, h, w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)


##########################################################################
## Gated-Dconv Feed-Forward Network (GDFN)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim * ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=3, stride=1, padding=1,
                                groups=hidden_features * 2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        return x
# hyc
class FNN(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FNN, self).__init__()

        hidden_features = int(dim * ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1,
                                groups=hidden_features, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x = F.gelu(x)
        x = self.dwconv(x)
        x = F.gelu(x)
        x = self.project_out(x)
        return x

##########################################################################
## Multi-DConv Head Transposed Self-Attention (MDTA)
class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, c, h, w = x.shape

        qkv = self.qkv_dwconv(self.qkv(x))
        q, k, v = qkv.chunk(3, dim=1)

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)

        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        out = self.project_out(out)
        return out
# hyc
class MTA_t(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(MTA_t, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, c, h, w = x.shape

        qkv = self.qkv_dwconv(self.qkv(x))
        q, k, v = qkv.chunk(3, dim=1)

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)

        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        out = self.project_out(out)
        return out
"""
class MTA_s(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(MTA_s, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

        self.mask_1 = nn.Conv2d(8, dim * 8, kernel_size=1, bias=bias)
        self.mask_2 = nn.Conv2d(dim * 8, dim * 8, kernel_size=1, bias=bias)
        self.mask_dwconv = nn.Conv2d(dim * 8, dim * 8, kernel_size=5, stride=1, padding=2, groups=dim * 8, bias=bias)

        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)


    def forward(self, x, maskt):
        b, c, h, w = x.shape

        qkv = self.qkv_dwconv(self.qkv(x))
        q, k, v = qkv.chunk(3, dim=1)

        q = rearrange(q, 'b c (head h) (head w) -> b (head head) (h w) c', head=self.num_heads)
        k = rearrange(k, 'b c (head h) (head w) -> b (head head) (h w) c', head=self.num_heads)
        v = rearrange(v, 'b c (head h) (head w) -> b (head head) (h w) c', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)

        out = rearrange(out, 'b (head head) (h w) c -> b c (head h) (head w)', head=self.num_heads, c=c)
        out = self.project_out(out)

        mask_all = self.lrelu(self.mask_1(maskt))
        mask_tmp = self.mask_dwconv( self.lrelu(self.mask_2(mask_all)))
        b1, c1, h1, w1 = mask_tmp.shape
        mask_tmp = mask_tmp.view(b1, c1, h1 * w1)
        mask_tmp = mask_tmp.sigmoid(dim=-1)
        mask_tmp = mask_tmp.view(b1, c1, h1, w1)
        mask_tmp = mask_tmp * mask_all
        mask_all = mask_all + mask_tmp

        mask0, mask1, mask2, mask3, mask4, mask5, mask6, mask7 = mask_all.chunk(8, dim=1)

        out2 = []
        out2.append(mask0 * out)
        out2.append(mask1 * out)
        out2.append(mask2 * out)
        out2.append(mask3 * out)
        out2.append(mask4 * out)
        out2.append(mask5 * out)
        out2.append(mask6 * out)
        out2.append(mask7 * out)
        out3 = torch.stack(out2, dim=1) # B N C H W

        return out3
"""
class MTA_s(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(MTA_s, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

        #self.mask_2 = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        #self.mask_dwconv = nn.Conv2d(dim, dim, kernel_size=5, stride=1, padding=2, groups=dim, bias=bias)

        #self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)

        self.down = Downsample_mask(10)

        self.po1 = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=bias)
        self.po2 = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=bias)

        self.temperature_m = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.mask_1 = nn.Conv2d(10, dim, kernel_size=1, bias=bias)
        self.qkv_m = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv_m = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out_m = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

        self.po1_m = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=bias)
        self.po2_m = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=bias)


    def forward(self, x):
        b, c, h, w = x.shape
        mask = self.mask.to(x.device)
        cc, hh, ww = mask.shape
        maskt = mask.expand([b, cc, hh, ww])
        #maskt = F.interpolate(maskt, size=[h, w], mode="bilinear", align_corners = True)
        if h == hh / 2:
            maskt = self.down(maskt)
        elif h == hh / 4:
            maskt = self.down(maskt)
            maskt = self.down(maskt)

        mask_tmp = self.mask_1(maskt)

        b_m, c_m, h_m, w_m = mask_tmp.shape

        qkv_m = self.qkv_dwconv_m(self.qkv_m(mask_tmp))
        q_m, k_m, v_m = qkv_m.chunk(3, dim=1)

        position_m = self.po1_m(v_m)
        position_m = F.gelu(position_m)
        position_m = self.po2_m(position_m)

        q_m = rearrange(q_m, 'b_m (head c_m) h_m w_m -> b_m head c_m (h_m w_m)', head=self.num_heads)
        k_m = rearrange(k_m, 'b_m (head c_m) h_m w_m -> b_m head c_m (h_m w_m)', head=self.num_heads)
        v_m = rearrange(v_m, 'b_m (head c_m) h_m w_m -> b_m head c_m (h_m w_m)', head=self.num_heads)

        q_m = torch.nn.functional.normalize(q_m, dim=-1)
        k_m = torch.nn.functional.normalize(k_m, dim=-1)

        attn_m = (q_m @ k_m.transpose(-2, -1)) * self.temperature_m
        attn_m = attn_m.softmax(dim=-1)

        out_m = (attn_m @ v_m)

        out_m = rearrange(out_m, 'b_m head c_m (h_m w_m) -> b_m (head c_m) h_m w_m', head=self.num_heads, h_m=h_m,
                          w_m=w_m)

        out_m = self.project_out_m(out_m) + position_m

        out_m = out_m.sigmoid()
        out_m = out_m * mask_tmp + mask_tmp


        qkv = self.qkv_dwconv(self.qkv(x))
        q, k, v = qkv.chunk(3, dim=1)

        position = self.po1(v)
        position = F.gelu(position)
        position = self.po2(position)

        v = v * out_m

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)

        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        out = self.project_out(out) + position

        return out


class MTA(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(MTA, self).__init__()
        self.MTA_s = MTA_s(dim, num_heads, bias)
        self.MTA_t = MTA_t(dim, num_heads, bias)

    def forward(self, x_meas):
        out_s = self.MTA_s(x_meas)
        out_t = self.MTA_t(out_s)

        return out_t

##########################################################################
class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, ffn_expansion_factor, bias, LayerNorm_type):
        super(TransformerBlock, self).__init__()

        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(dim, ffn_expansion_factor, bias)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))

        return x
# hyc
class TransformerB(nn.Module):
    def __init__(self, dim, num_heads, ffn_expansion_factor, bias, LayerNorm_type):
        super(TransformerB, self).__init__()

        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = MTA_s(dim, num_heads, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FNN(dim, ffn_expansion_factor, bias)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))

        return x
##########################################################################
## Overlapped image patch embedding with 3x3 Conv
class OverlapPatchEmbed(nn.Module):
    def __init__(self, in_c=3, embed_dim=48, bias=False):
        super(OverlapPatchEmbed, self).__init__()

        self.proj = nn.Conv2d(1, 64, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, x):
        x = self.proj(x)

        return x


##########################################################################
class Downsample(nn.Module):
    def __init__(self, in_channel):
        super(Downsample, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channel, in_channel * 2, kernel_size=4, stride=2, padding=1, bias=False),
        )

    def forward(self, x):
        out = self.conv(x)
        return out

# Upsample Block
class Upsample(nn.Module):
    def __init__(self, in_channel):
        super(Upsample, self).__init__()
        self.deconv = nn.Sequential(
            nn.ConvTranspose2d(in_channel, in_channel // 2, kernel_size=2, stride=2, bias=False),
        )

    def forward(self, x):
        out = self.deconv(x)
        return out

class Downsample_mask(nn.Module):
    def __init__(self, in_channel):
        super(Downsample_mask, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=4, stride=2, padding=1, bias=False),
        )

    def forward(self, x):
        out = self.conv(x)
        return out
## Resizing modules
"""
class Downsample(nn.Module):
    def __init__(self, n_feat):
        super(Downsample, self).__init__()

        self.body = nn.Sequential(nn.Conv2d(n_feat, n_feat // 2, kernel_size=3, stride=1, padding=1, bias=False),
                                  nn.PixelShuffle(1/2))

    def forward(self, x):
        return self.body(x)


class Upsample(nn.Module):
    def __init__(self, n_feat):
        super(Upsample, self).__init__()

        self.body = nn.Sequential(nn.Conv2d(n_feat, n_feat * 2, kernel_size=3, stride=1, padding=1, bias=False),
                                  nn.PixelShuffle(2))

    def forward(self, x):
        return self.body(x)
"""
class ResBlock(nn.Module):
    def __init__(
        self, n_feats, bias=True, bn=False, act=nn.ReLU(True)):

        super(ResBlock, self).__init__()
        m = []
        for i in range(2):
            m.append(nn.Conv2d(n_feats, n_feats, kernel_size=3, stride=1, padding=1, bias=bias))
            if bn:
                m.append(nn.BatchNorm2d(n_feats))
            if i == 0:
                m.append(act)

        self.body = nn.Sequential(*m)

    def forward(self, x):
        res = self.body(x)
        res += x

        return res

class nResBlock(nn.Module):
    def __init__(
            self, n, n_feats, bias=False, bn=False, act=nn.ReLU(True)):
        super(nResBlock, self).__init__()
        m = []
        for i in range(n):
            m.append(ResBlock(n_feats, bias=bias, bn=bn, act=act))
        self.body = nn.Sequential(*m)
    def forward(self, x):
        x = self.body(x)
        return x

##########################################################################
##---------- Restormer -----------------------
class Restormer(nn.Module):
    def __init__(self,
                 inp_channels=3,
                 out_channels=3,
                 dim=48,
                 num_blocks=[4, 6, 6, 8],
                 num_refinement_blocks=4,
                 heads=[1, 2, 4, 8],
                 ffn_expansion_factor=2.66,
                 bias=False,
                 LayerNorm_type='WithBias',  ## Other option 'BiasFree'
                 dual_pixel_task=False  ## True for dual-pixel defocus deblurring only. Also set inp_channels=6
                 ):

        super(Restormer, self).__init__()

        self.patch_embed = OverlapPatchEmbed(inp_channels, dim)

        self.encoder_level1 = nn.Sequential(*[
            TransformerBlock(dim=dim, num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for i in range(num_blocks[0])])

        self.down1_2 = Downsample(dim)  ## From Level 1 to Level 2
        self.encoder_level2 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 1), num_heads=heads[1], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[1])])

        self.down2_3 = Downsample(int(dim * 2 ** 1))  ## From Level 2 to Level 3
        self.encoder_level3 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 2), num_heads=heads[2], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[2])])

        self.down3_4 = Downsample(int(dim * 2 ** 2))  ## From Level 3 to Level 4
        self.latent = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 3), num_heads=heads[3], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[3])])

        self.up4_3 = Upsample(int(dim * 2 ** 3))  ## From Level 4 to Level 3
        self.reduce_chan_level3 = nn.Conv2d(int(dim * 2 ** 3), int(dim * 2 ** 2), kernel_size=1, bias=bias)
        self.decoder_level3 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 2), num_heads=heads[2], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[2])])

        self.up3_2 = Upsample(int(dim * 2 ** 2))  ## From Level 3 to Level 2
        self.reduce_chan_level2 = nn.Conv2d(int(dim * 2 ** 2), int(dim * 2 ** 1), kernel_size=1, bias=bias)
        self.decoder_level2 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 1), num_heads=heads[1], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[1])])

        self.up2_1 = Upsample(int(dim * 2 ** 1))  ## From Level 2 to Level 1  (NO 1x1 conv to reduce channels)

        self.decoder_level1 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 1), num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[0])])

        self.refinement = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 1), num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_refinement_blocks)])

        #### For Dual-Pixel Defocus Deblurring Task ####
        self.dual_pixel_task = dual_pixel_task
        if self.dual_pixel_task:
            self.skip_conv = nn.Conv2d(dim, int(dim * 2 ** 1), kernel_size=1, bias=bias)
        ###########################

        self.output = nn.Conv2d(int(dim * 2 ** 1), out_channels, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, inp_img):

        inp_enc_level1 = self.patch_embed(inp_img)
        out_enc_level1 = self.encoder_level1(inp_enc_level1)

        inp_enc_level2 = self.down1_2(out_enc_level1)
        out_enc_level2 = self.encoder_level2(inp_enc_level2)

        inp_enc_level3 = self.down2_3(out_enc_level2)
        out_enc_level3 = self.encoder_level3(inp_enc_level3)

        inp_enc_level4 = self.down3_4(out_enc_level3)
        latent = self.latent(inp_enc_level4)

        inp_dec_level3 = self.up4_3(latent)
        inp_dec_level3 = torch.cat([inp_dec_level3, out_enc_level3], 1)
        inp_dec_level3 = self.reduce_chan_level3(inp_dec_level3)
        out_dec_level3 = self.decoder_level3(inp_dec_level3)

        inp_dec_level2 = self.up3_2(out_dec_level3)
        inp_dec_level2 = torch.cat([inp_dec_level2, out_enc_level2], 1)
        inp_dec_level2 = self.reduce_chan_level2(inp_dec_level2)
        out_dec_level2 = self.decoder_level2(inp_dec_level2)

        inp_dec_level1 = self.up2_1(out_dec_level2)
        inp_dec_level1 = torch.cat([inp_dec_level1, out_enc_level1], 1)
        out_dec_level1 = self.decoder_level1(inp_dec_level1)

        out_dec_level1 = self.refinement(out_dec_level1)

        #### For Dual-Pixel Defocus Deblurring Task ####
        if self.dual_pixel_task:
            out_dec_level1 = out_dec_level1 + self.skip_conv(inp_enc_level1)
            out_dec_level1 = self.output(out_dec_level1)
        ###########################
        else:
            out_dec_level1 = self.output(out_dec_level1) + inp_img

        return out_dec_level1

class SCIformer(nn.Module):
    def __init__(self,
                 inp_channels=10,
                 out_channels=10,
                 dim=64,
                 num_blocks=[4, 7, 5],
                 heads=[1, 2, 4],
                 ffn_expansion_factor=4,
                 num_resblock = 5,
                 bias=False,
                 LayerNorm_type='WithBias'  ## Other option 'BiasFree'
                 ):

        super(SCIformer, self).__init__()

        self.patch_embed = OverlapPatchEmbed(inp_channels, dim)

        self.encoder_level1 = nn.Sequential(*[
            TransformerB(dim=dim, num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for i in range(num_blocks[0])])

        self.down1_2 = Downsample(dim)  ## From Level 1 to Level 2, H/2 X W/2 X 2C
        self.encoder_level2 = nn.Sequential(*[
            TransformerB(dim=int(dim * 2 ** 1), num_heads=heads[1], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[1])])

        self.down2_3 = Downsample(int(dim * 2 ** 1))  ## From Level 2 to Level 3, H/4 X W/4 X 4C
        self.encoder_level3 = nn.Sequential(*[
            TransformerB(dim=int(dim * 2 ** 2), num_heads=heads[2], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[2])])

        self.up3_2 = Upsample(int(dim * 2 ** 2))  ## From Level 3 to Level 2, H/2 X W/2 X 2C
        self.reduce_chan_level2 = nn.Conv2d(int(dim * 2 ** 2), int(dim * 2 ** 1), kernel_size=1, bias=bias)
        self.decoder_level2 = nn.Sequential(*[
            TransformerB(dim=int(dim * 2 ** 1), num_heads=heads[1], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[1])])

        self.up2_1 = Upsample(int(dim * 2 ** 1))  ## From Level 2 to Level 1, H X W X C
        self.reduce_chan_level1 = nn.Conv2d(int(dim * 2 ** 1), int(dim), kernel_size=1, bias=bias)
        self.decoder_level1 = nn.Sequential(*[
            TransformerB(dim=int(dim), num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[0])])

        self.output2 = nn.Conv2d(int(dim), out_channels, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, y):
        # meas_re: 5X1X256X256

        b, c, h, w = y.shape
        mask = self.mask.to(y.device)  # 8X256X256
        maskt = mask.expand([b, 10, h, w])  # 5x8x256x256
        mask_new = maskt.mul(y)  # 5x8x256x256
        data1 = y + mask_new  # 5x8x256x256
        #data1 = mask_new

        #Phisum = torch.sum(mask * mask, 0, keepdim=True)
        #y_ = y / Phisum

        #data1 = At_operator(y, mask)
        #data1 = data1 + y

        #data1 = data1.squeeze(2)
        #y_ = y_.squeeze(2)

        #data = torch.cat((data1,meas_re), dim=1)

        inp_enc_level1 = self.patch_embed(y)
        inp_enc_level1 = self.patch_embed2(inp_enc_level1)
        out_enc_level1 = self.encoder_level1(inp_enc_level1)

        inp_enc_level2 = self.down1_2(out_enc_level1)
        out_enc_level2 = self.encoder_level2(inp_enc_level2)

        inp_bottle = self.down2_3(out_enc_level2)
        out_bottle = self.encoder_level3(inp_bottle)

        inp_dec_level2 = self.up3_2(out_bottle)
        inp_dec_level2 = torch.cat([inp_dec_level2, out_enc_level2], 1)
        inp_dec_level2 = self.reduce_chan_level2(inp_dec_level2)
        out_dec_level2 = self.decoder_level2(inp_dec_level2)

        inp_dec_level1 = self.up2_1(out_dec_level2)
        inp_dec_level1 = torch.cat([inp_dec_level1, out_enc_level1], 1)
        inp_dec_level1 = self.reduce_chan_level1(inp_dec_level1)
        out_dec_level1 = self.decoder_level1(inp_dec_level1)

        out_dec_level1 = self.output2(self.output(out_dec_level1)) + data1

        out_dec_level1 = out_dec_level1.unsqueeze(2)

        return out_dec_level1



import torch.nn as nn
import torch
import torch.nn.functional as F
from einops import rearrange
import math
import warnings
from torch.nn.init import _calculate_fan_in_and_fan_out

def _no_grad_trunc_normal_(tensor, mean, std, a, b):
    def norm_cdf(x):
        return (1. + math.erf(x / math.sqrt(2.))) / 2.

    if (mean < a - 2 * std) or (mean > b + 2 * std):
        warnings.warn("mean is more than 2 std from [a, b] in nn.init.trunc_normal_. "
                      "The distribution of values may be incorrect.",
                      stacklevel=2)
    with torch.no_grad():
        l = norm_cdf((a - mean) / std)
        u = norm_cdf((b - mean) / std)
        tensor.uniform_(2 * l - 1, 2 * u - 1)
        tensor.erfinv_()
        tensor.mul_(std * math.sqrt(2.))
        tensor.add_(mean)
        tensor.clamp_(min=a, max=b)
        return tensor


def trunc_normal_(tensor, mean=0., std=1., a=-2., b=2.):
    # type: (Tensor, float, float, float, float) -> Tensor
    return _no_grad_trunc_normal_(tensor, mean, std, a, b)


def variance_scaling_(tensor, scale=1.0, mode='fan_in', distribution='normal'):
    fan_in, fan_out = _calculate_fan_in_and_fan_out(tensor)
    if mode == 'fan_in':
        denom = fan_in
    elif mode == 'fan_out':
        denom = fan_out
    elif mode == 'fan_avg':
        denom = (fan_in + fan_out) / 2
    variance = scale / denom
    if distribution == "truncated_normal":
        trunc_normal_(tensor, std=math.sqrt(variance) / .87962566103423978)
    elif distribution == "normal":
        tensor.normal_(std=math.sqrt(variance))
    elif distribution == "uniform":
        bound = math.sqrt(3 * variance)
        tensor.uniform_(-bound, bound)
    else:
        raise ValueError(f"invalid distribution {distribution}")


def lecun_normal_(tensor):
    variance_scaling_(tensor, mode='fan_in', distribution='truncated_normal')


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.fn = fn
        self.norm = nn.LayerNorm(dim)

    def forward(self, x, *args, **kwargs):
        x = self.norm(x)
        return self.fn(x, *args, **kwargs)


class GELU(nn.Module):
    def forward(self, x):
        return F.gelu(x)

def conv(in_channels, out_channels, kernel_size, bias=False, padding = 1, stride = 1):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size//2), bias=bias, stride=stride)

def shift_back(inputs,step=2):          # input [bs,28,256,310]  output [bs, 28, 256, 256]
    [bs, nC, row, col] = inputs.shape
    down_sample = 256//row
    step = float(step)/float(down_sample*down_sample)
    out_col = row
    for i in range(nC):
        inputs[:,i,:,:out_col] = \
            inputs[:,i,:,int(step*i):int(step*i)+out_col]
    return inputs[:, :, :, :out_col]

class MaskGuidedMechanism(nn.Module):
    def __init__(
            self, n_feat):
        super(MaskGuidedMechanism, self).__init__()

        self.conv1 = nn.Conv2d(n_feat, n_feat, kernel_size=1, bias=True)
        self.conv2 = nn.Conv2d(n_feat, n_feat, kernel_size=1, bias=True)
        self.depth_conv = nn.Conv2d(n_feat, n_feat, kernel_size=5, padding=2, bias=True, groups=n_feat)

    def forward(self, mask):
        # x: b,c,h,w
        [bs, nC, row, col] = mask.shape
        mask = self.conv1(mask)
        attn_map = torch.sigmoid(self.depth_conv(self.conv2(mask)))
        res = mask * attn_map
        mask = res + mask
        return mask

class MS_MSA(nn.Module):
    def __init__(
            self,
            dim,
            dim_head=64,
            heads=8,
    ):
        super().__init__()
        self.num_heads = heads
        self.dim_head = dim_head
        self.to_q = nn.Linear(dim, dim_head * heads, bias=False)
        self.to_k = nn.Linear(dim, dim_head * heads, bias=False)
        self.to_v = nn.Linear(dim, dim_head * heads, bias=False)
        self.rescale = nn.Parameter(torch.ones(heads, 1, 1))
        self.proj = nn.Linear(dim_head * heads, dim, bias=True)
        self.pos_emb = nn.Sequential(
            nn.Conv2d(dim, dim, 3, 1, 1, bias=False, groups=dim),
            GELU(),
            nn.Conv2d(dim, dim, 3, 1, 1, bias=False, groups=dim),
        )
        self.mm = MaskGuidedMechanism(dim)
        self.dim = dim

    def forward(self, x_in, mask=None):
        """
        x_in: [b,h,w,c]
        mask: [1,h,w,c]
        return out: [b,h,w,c]
        """
        b, h, w, c = x_in.shape
        x = x_in.reshape(b,h*w,c)
        q_inp = self.to_q(x)
        k_inp = self.to_k(x)
        v_inp = self.to_v(x)

        mask_attn = self.mm(mask.permute(0,3,1,2)).permute(0,2,3,1)
        if b != 0:
            mask_attn = (mask_attn[0, :, :, :]).expand([b, h, w, c])
        q, k, v, mask_attn = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h=self.num_heads),
                                (q_inp, k_inp, v_inp, mask_attn.flatten(1, 2)))
        v = v * mask_attn
        # q: b,heads,hw,c
        q = q.transpose(-2, -1)
        k = k.transpose(-2, -1)
        v = v.transpose(-2, -1)
        q = F.normalize(q, dim=-1, p=2)
        k = F.normalize(k, dim=-1, p=2)
        attn = (k @ q.transpose(-2, -1))   # A = K^T*Q
        attn = attn * self.rescale
        attn = attn.softmax(dim=-1)
        x = attn @ v   # b,heads,d,hw
        x = x.permute(0, 3, 1, 2)    # Transpose
        x = x.reshape(b, h * w, self.num_heads * self.dim_head)
        out_c = self.proj(x).view(b, h, w, c)
        out_p = self.pos_emb(v_inp.reshape(b,h,w,c).permute(0, 3, 1, 2)).permute(0, 2, 3, 1)
        out = out_c + out_p

        return out

class FeedForward(nn.Module):
    def __init__(self, dim, mult=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(dim, dim * mult, 1, 1, bias=False),
            GELU(),
            nn.Conv2d(dim * mult, dim * mult, 3, 1, 1, bias=False, groups=dim * mult),
            GELU(),
            nn.Conv2d(dim * mult, dim, 1, 1, bias=False),
        )

    def forward(self, x):
        """
        x: [b,h,w,c]
        return out: [b,h,w,c]
        """
        out = self.net(x.permute(0, 3, 1, 2))
        return out.permute(0, 2, 3, 1)

class MSAB(nn.Module):
    def __init__(
            self,
            dim,
            dim_head=64,
            heads=8,
            num_blocks=2,
    ):
        super().__init__()
        self.blocks = nn.ModuleList([])
        for _ in range(num_blocks):
            self.blocks.append(nn.ModuleList([
                MS_MSA(dim=dim, dim_head=dim_head, heads=heads),
                PreNorm(dim, FeedForward(dim=dim))
            ]))

    def forward(self, x, mask):
        """
        x: [b,c,h,w]
        return out: [b,c,h,w]
        """
        x = x.permute(0, 2, 3, 1)
        for (attn, ff) in self.blocks:
            x = attn(x, mask=mask.permute(0, 2, 3, 1)) + x
            x = ff(x) + x
        out = x.permute(0, 3, 1, 2)
        return out


class MST(nn.Module):
    def __init__(self, dim=64, stage=3, num_blocks=[4,7,5]):
        super(MST, self).__init__()
        self.dim = dim
        self.stage = stage

        # Input projection
        self.embedding = nn.Conv2d(1, self.dim, 3, 1, 1, bias=False)
        self.embedding_mask = nn.Conv2d(8, self.dim, 3, 1, 1, bias=False)

        # Encoder
        self.encoder_layers = nn.ModuleList([])
        dim_stage = dim
        for i in range(stage):
            self.encoder_layers.append(nn.ModuleList([
                MSAB(
                    dim=dim_stage, num_blocks=num_blocks[i], dim_head=dim, heads=dim_stage // dim),
                nn.Conv2d(dim_stage, dim_stage * 2, 4, 2, 1, bias=False),
                nn.Conv2d(dim_stage, dim_stage * 2, 4, 2, 1, bias=False)
            ]))
            dim_stage *= 2

        # Bottleneck
        self.bottleneck = MSAB(
            dim=dim_stage, dim_head=dim, heads=dim_stage // dim, num_blocks=num_blocks[-1])

        # Decoder
        self.decoder_layers = nn.ModuleList([])
        for i in range(stage):
            self.decoder_layers.append(nn.ModuleList([
                nn.ConvTranspose2d(dim_stage, dim_stage // 2, stride=2, kernel_size=2, padding=0, output_padding=0),
                nn.Conv2d(dim_stage, dim_stage // 2, 1, 1, bias=False),
                MSAB(
                    dim=dim_stage // 2, num_blocks=num_blocks[stage - 1 - i], dim_head=dim,
                    heads=(dim_stage // 2) // dim),
            ]))
            dim_stage //= 2

        # Output projection
        self.mapping = nn.Conv2d(self.dim, 8, 3, 1, 1, bias=False)

        #### activation function
        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)

    def forward(self, x):
        """
        x: [b,c,h,w]
        return out:[b,c,h,w]
        """
        #if mask == None:
        #    mask = torch.zeros((1,28,128,128)).cuda()
        # hyc
        b, c, h, w = x.shape
        maskt = self.mask.to(x.device)  # 8X256X256
        mask = maskt.expand([b, 8, h, w])  # 5x8x256x256
        mask_new = mask.mul(x)  # 5x8x256x256
        data1 = x + mask_new  # 5x8x256x256
        mask = self.lrelu(self.embedding_mask(mask))

        # Embedding
        fea = self.lrelu(self.embedding(x))

        # Encoder
        fea_encoder = []
        masks = []
        for (MSAB, FeaDownSample, MaskDownSample) in self.encoder_layers:
            fea = MSAB(fea, mask)
            masks.append(mask)
            fea_encoder.append(fea)
            fea = FeaDownSample(fea)
            mask = MaskDownSample(mask)

        # Bottleneck
        fea = self.bottleneck(fea, mask)

        # Decoder
        for i, (FeaUpSample, Fution, LeWinBlcok) in enumerate(self.decoder_layers):
            fea = FeaUpSample(fea)
            fea = Fution(torch.cat([fea, fea_encoder[self.stage-1-i]], dim=1))
            mask = masks[self.stage - 1 - i]
            fea = LeWinBlcok(fea, mask)

        # Mapping
        out = self.mapping(fea) + data1
        out = out.unsqueeze(2)

        return out