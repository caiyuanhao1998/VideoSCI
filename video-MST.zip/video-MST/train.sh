#!/bin/bash

export OMP_NUM_THREADS="4"

#CUDA_VISIBLE_DEVICES=3,4,5,6 python -m torch.distributed.launch --nproc_per_node=4 train.py --batch_size 4 --learning_rate 4e-6 --max_number_patches 25600  --patch_size 128 --n_channels 1 --layer_num 4  --warmup_steps 5 --opt-level O1 --end_epoch 200 --algo_name 3DCN_RFMA_layer10
CUDA_VISIBLE_DEVICES=3,4,5,6 python -m torch.distributed.launch --nproc_per_node=4 train.py --batch_size 4 --learning_rate 2e-5 --max_number_patches 25600  --patch_size 128 --n_channels 1 --layer_num 4  --warmup_steps 5 --opt-level O1 --end_epoch 400 --algo_name MST1